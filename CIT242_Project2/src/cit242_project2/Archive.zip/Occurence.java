package cit242_project2;
public class Occurence {
	
	// private variables
	private int lineNumber = 0;
	private int position = 0;
	private char leftValue;
	private char expectedRightValue;
	
	// constructor that sets values. Also calls a method that sets the expectedRightValue 
	public Occurence(int lineNumber, int position, char leftValue) {
		
		setLineNumber(lineNumber);
		setPosition(position);
		setLeftValue(leftValue);
		balancedValue(this.leftValue); // set expected value 
	}
	
	// getters
	public int getLineNumber() {
	       return lineNumber;
	    }
	public int getPosition() {
		return position;	
	}
	public char getLeftValue() {
	       return leftValue;
	    }
	public char getExpectedRightValue() {
	       return expectedRightValue;
	    }
	
	// setters
	  public void setLineNumber(int lineNumber) {
	       this.lineNumber = lineNumber;
	    }
	  public void setPosition(int position) {
	       this.position = position;
	    }
	  public void setLeftValue(char leftValue) {
		  this.leftValue = leftValue;
	  }
	  public void setExpectedRightValue(char expectedRightValue) {
		  this.expectedRightValue = expectedRightValue;
		  
	  }
	  // setting the expected right value
	  public void balancedValue(char leftValue) {
		  
		  if(leftValue == '(') {setExpectedRightValue(')');}
		  if(leftValue == '[') {setExpectedRightValue(']');}
		  if(leftValue == '{') {setExpectedRightValue('}');}
	  }
	  
	  // may need to look at this again 
	  public boolean isBalanced(char c) {
		 
		  if(c == expectedRightValue) return true;
		  else return false;
	  }
	  
	  // toString method. Simply outputs line and position 
	  @Override
	  public String toString() {
		  int value = getLineNumber()+1;
	   return String.format("line %d, position %d", value, getPosition());
	  }
	

}
